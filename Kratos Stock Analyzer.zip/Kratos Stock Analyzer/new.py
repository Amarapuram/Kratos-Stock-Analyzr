import http.client

conn = http.client.HTTPSConnection("stock-scraper.p.rapidapi.com")

headers = {
    'X-RapidAPI-Key': "a8e0cdeb01msh9a6b3d9e6912f93p1e0cbbjsn91342d1714b5",
    'X-RapidAPI-Host': "stock-scraper.p.rapidapi.com"
}

conn.request("GET", "/", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))