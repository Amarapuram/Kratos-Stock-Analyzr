import requests
import pprint
# replace the "demo" apikey below with your own key from https://www.alphavantage.co/support/#api-key
url = 'https://www.alphavantage.co/query?function=INCOME_STATEMENT&symbol=IBM&apikey=PJ09BSCD2CO867PD'
r = requests.get(url)
data = r.json()

pprint.pprint(data)